% Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms
% Copyright (C) 2014  Max Plomer
 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact info for Max Plomer
% email: maxplomer@gmail.com
% cell: 203-945-8606

function [fwdk,revk]=getkfkr(T,Y)
RU=83145100; %erg/(mol*K)
PATM=1.01325D6/RU;
g=getg(T)/RU;
sumY=sum(Y);
revk=zeros(1,21);
fwdk=zeros(1,21);
[A, B, E]=getabe;
kfarray=A.*T.^B.*exp(-E*41840000/(RU*T));
d = 0.14;%troe

kf=kfarray(1);
fwdk(1)=kf*Y(2)*Y(4);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(5)*1+g(6)*1)  /  T  );
revk(1)=kf/Kc*Y(5)*Y(6);

kf=kfarray(2);
fwdk(2)=kf*Y(1)*Y(5);
Kc=exp(   -(+g(1)*-1+g(4)*1+g(5)*-1+g(6)*1)  /  T  );
revk(2)=kf/Kc*Y(4)*Y(6);

kf=kfarray(3);
fwdk(3)=kf*Y(1)*Y(6);
Kc=exp(   -(+g(1)*-1+g(3)*1+g(4)*1+g(6)*-1)  /  T  );
revk(3)=kf/Kc*Y(3)*Y(4);

kf=kfarray(4);
fwdk(4)=kf*Y(3)*Y(5);
Kc=exp(   -(+g(3)*-1+g(5)*-1+g(6)*2)  /  T  );
revk(4)=kf/Kc*Y(6)*Y(6);

kf=kfarray(5)*(sumY+Y(1)*1.5+Y(3)*11);
fwdk(5)=kf*Y(1);
Kc=exp(   -(+g(1)*-1+g(4)*2)  /  T  )/(T/PATM);
revk(5)=kf/Kc*Y(4)*Y(4);

kf=kfarray(6)*(sumY+Y(1)*1.5+Y(3)*11);
fwdk(6)=kf*Y(5)*Y(5);
Kc=exp(   -(+g(2)*1+g(5)*-2)  /  T  )*(T/PATM);
revk(6)=kf/Kc*Y(2);

kf=kfarray(7)*(sumY+Y(1)*1.5+Y(3)*11);
fwdk(7)=kf*Y(4)*Y(5);
Kc=exp(   -(+g(4)*-1+g(5)*-1+g(6)*1)  /  T  )*(T/PATM);
revk(7)=kf/Kc*Y(6);

kf=kfarray(8)*(sumY+Y(1)*1.5+Y(3)*11);
fwdk(8)=kf*Y(4)*Y(6);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(6)*-1)  /  T  )*(T/PATM);
revk(8)=kf/Kc*Y(3);

%lindemann approach
k0=6.366E+20*T^-1.72*exp(-2.640881e+02/T);
kinf=kfarray(9);
Pr=(k0*(sumY+Y(1)*1+Y(3)*10+Y(2)*-0.22))/kinf;
%Troe form
a=0.8;%alpha
T3=1E-30;%T***
T1=1E+30;%T*
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1);   %T** not included
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(9)=kf*Y(2)*Y(4);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(7)*1)  /  T  )*(T/PATM);
revk(9)=kf/Kc*Y(7);

kf=kfarray(10);
fwdk(10)=kf*Y(4)*Y(7);
Kc=exp(   -(+g(1)*1+g(2)*1+g(4)*-1+g(7)*-1)  /  T  );
revk(10)=kf/Kc*Y(1)*Y(2);

kf=kfarray(11);
fwdk(11)=kf*Y(4)*Y(7);
Kc=exp(   -(+g(4)*-1+g(6)*2+g(7)*-1)  /  T  );
revk(11)=kf/Kc*Y(6)*Y(6);

kf=kfarray(12);
fwdk(12)=kf*Y(5)*Y(7);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(6)*1+g(7)*-1)  /  T  );
revk(12)=kf/Kc*Y(2)*Y(6);

kf=kfarray(13);
fwdk(13)=kf*Y(6)*Y(7);
Kc=exp(   -(+g(2)*1+g(3)*1+g(6)*-1+g(7)*-1)  /  T  );
revk(13)=kf/Kc*Y(2)*Y(3);

kf=kfarray(14);
fwdk(14)=kf*Y(7)*Y(7);
Kc=exp(   -(+g(2)*1+g(7)*-2+g(8)*1)  /  T  );
revk(14)=kf/Kc*Y(2)*Y(8);

kf=kfarray(15);
fwdk(15)=kf*Y(7)*Y(7);
Kc=exp(   -(+g(2)*1+g(7)*-2+g(8)*1)  /  T  );
revk(15)=kf/Kc*Y(2)*Y(8);

%lindemann approach
k0=1.202E+17*exp(-2.289636e+04/T);
kinf=kfarray(16);
Pr=(k0*(sumY+Y(1)*1.5+Y(3)*11))/kinf;
%Troe form
a=0.5;%alpha
T3=1E-30;%T***
T1=1E+30;%T*
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1);   %T** not included
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(16)=kf*Y(8);
Kc=exp(   -(+g(6)*2+g(8)*-1)  /  T  )/(T/PATM);
revk(16)=kf/Kc*Y(6)*Y(6);

kf=kfarray(17);
fwdk(17)=kf*Y(4)*Y(8);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(6)*1+g(8)*-1)  /  T  );
revk(17)=kf/Kc*Y(3)*Y(6);

kf=kfarray(18);
fwdk(18)=kf*Y(4)*Y(8);
Kc=exp(   -(+g(1)*1+g(4)*-1+g(7)*1+g(8)*-1)  /  T  );
revk(18)=kf/Kc*Y(1)*Y(7);

kf=kfarray(19);
fwdk(19)=kf*Y(5)*Y(8);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(7)*1+g(8)*-1)  /  T  );
revk(19)=kf/Kc*Y(6)*Y(7);

kf=kfarray(20);
fwdk(20)=kf*Y(6)*Y(8);
Kc=exp(   -(+g(3)*1+g(6)*-1+g(7)*1+g(8)*-1)  /  T  );
revk(20)=kf/Kc*Y(3)*Y(7);

kf=kfarray(21);
fwdk(21)=kf*Y(6)*Y(8);
Kc=exp(   -(+g(3)*1+g(6)*-1+g(7)*1+g(8)*-1)  /  T  );
revk(21)=kf/Kc*Y(3)*Y(7);

end