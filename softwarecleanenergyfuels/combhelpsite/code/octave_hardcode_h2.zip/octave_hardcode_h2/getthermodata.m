% Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms
% Copyright (C) 2014  Max Plomer
 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact info for Max Plomer
% email: maxplomer@gmail.com
% cell: 203-945-8606

function [thermodata,commonT]=getthermodata
thermodata=[    2.99142337E+00     3.69757819E+00     2.67214561E+00     2.50000000E+00     2.54205966E+00     2.86472886E+00     4.01721090E+00     4.57316685E+00     0.02926640E+02  
        7.00064411E-04     6.13519689E-04     3.05629289E-03     0.00000000E+00    -2.75506191E-05     1.05650448E-03     2.23982013E-03     4.33613639E-03     0.01487977E-01  
       -5.63382869E-08    -1.25884199E-07    -8.73026011E-07     0.00000000E+00    -3.10280335E-09    -2.59082758E-07    -6.33658150E-07    -1.47468882E-06    -0.05684761E-05  
       -9.23157818E-12     1.77528148E-11     1.20099639E-10     0.00000000E+00     4.55106742E-12     3.05218674E-11     1.14246370E-10     2.34890357E-10     0.01009704E-08  
        1.58275179E-15    -1.13643531E-15    -6.39161787E-15     0.00000000E+00    -4.36805150E-16    -1.33195876E-15    -1.07908535E-14    -1.43165356E-14    -0.06753351E-13  
       -8.35033997E+02    -1.23393018E+03    -2.98992090E+04     2.54716270E+04     2.92308027E+04     3.68362875E+03     1.11856713E+02    -1.80069609E+04    -0.09227977E+04  
       -1.35511017E+00     3.18916559E+00     6.86281681E+00    -4.60117638E-01     4.92030811E+00     5.70164073E+00     3.78510215E+00     5.01136959E-01     0.05980528E+02  
        3.29812431E+00     3.21293640E+00     3.38684249E+00     2.50000000E+00     2.94642878E+00     4.12530561E+00     4.30179801E+00     3.38875365E+00     0.03298677E+02  
        8.24944174E-04     1.12748635E-03     3.47498246E-03     0.00000000E+00    -1.63816649E-03    -3.22544939E-03    -4.74912051E-03     6.56922581E-03     0.01408240E-01  
       -8.14301529E-07    -5.75615047E-07    -6.35469633E-06     0.00000000E+00     2.42103170E-06     6.52764691E-06     2.11582891E-05    -1.48501258E-07    -0.03963222E-04  
       -9.47543433E-11     1.31387723E-09     6.96858127E-09     0.00000000E+00    -1.60284319E-09    -5.79853643E-09    -2.42763894E-08    -4.62580552E-09     0.05641515E-07  
        4.13487224E-13    -8.76855392E-13    -2.50658847E-12     0.00000000E+00     3.89069636E-13     2.06237379E-12     9.29225124E-12     2.47151475E-12    -0.02444855E-10  
       -1.01252087E+03    -1.00524902E+03    -3.02081133E+04     2.54716270E+04     2.91476445E+04     3.34630913E+03     2.94808040E+02    -1.76631465E+04    -0.01020900E+05  
       -3.29409409E+00     6.03473759E+00     2.59023285E+00    -4.60117608E-01     2.96399498E+00    -6.90432960E-01     3.71666245E+00     6.78536320E+00     0.03950372E+02  ];
commonT=[ 1000.00
 1000.00
 1000.00
 1000.00
 1000.00
 1000.  
  1000.0
 1000.00
 1000.00];
end