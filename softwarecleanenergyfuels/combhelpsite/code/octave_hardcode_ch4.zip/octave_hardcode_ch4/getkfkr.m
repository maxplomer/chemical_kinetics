% Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms
% Copyright (C) 2014  Max Plomer
 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact info for Max Plomer
% email: maxplomer@gmail.com
% cell: 203-945-8606

function [fwdk,revk]=getkfkr(T,Y)
RU=83145100; %erg/(mol*K)
PATM=1.01325D6/RU;
g=getg(T)/RU;
sumY=sum(Y);
revk=zeros(1,325);
fwdk=zeros(1,325);
[A, B, E]=getabe;
kfarray=A.*T.^B.*exp(-E*41840000/(RU*T));
d = 0.14;%troe

kf=kfarray(1)*(sumY+Y(1)*1.4+Y(6)*14.4+Y(14)*1+Y(15)*0.75+Y(16)*2.6+Y(27)*2+Y(49)*-0.17);
fwdk(1)=kf*Y(3)*Y(3);
Kc=exp(   -(+g(3)*-2+g(4)*1)  /  T  )*(T/PATM);
revk(1)=kf/Kc*Y(4);

kf=kfarray(2)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(2)=kf*Y(2)*Y(3);
Kc=exp(   -(+g(2)*-1+g(3)*-1+g(5)*1)  /  T  )*(T/PATM);
revk(2)=kf/Kc*Y(5);

kf=kfarray(3);
fwdk(3)=kf*Y(1)*Y(3);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(3)*-1+g(5)*1)  /  T  );
revk(3)=kf/Kc*Y(2)*Y(5);

kf=kfarray(4);
fwdk(4)=kf*Y(3)*Y(7);
Kc=exp(   -(+g(3)*-1+g(4)*1+g(5)*1+g(7)*-1)  /  T  );
revk(4)=kf/Kc*Y(4)*Y(5);

kf=kfarray(5);
fwdk(5)=kf*Y(3)*Y(8);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(7)*1+g(8)*-1)  /  T  );
revk(5)=kf/Kc*Y(5)*Y(7);

kf=kfarray(6);
fwdk(6)=kf*Y(3)*Y(10);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(10)*-1+g(15)*1)  /  T  );
revk(6)=kf/Kc*Y(2)*Y(15);

kf=kfarray(7);
fwdk(7)=kf*Y(3)*Y(11);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(11)*-1+g(17)*1)  /  T  );
revk(7)=kf/Kc*Y(2)*Y(17);

kf=kfarray(8);
fwdk(8)=kf*Y(3)*Y(12);
Kc=exp(   -(+g(1)*1+g(3)*-1+g(12)*-1+g(15)*1)  /  T  );
revk(8)=kf/Kc*Y(1)*Y(15);

kf=kfarray(9);
fwdk(9)=kf*Y(3)*Y(12);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(12)*-1+g(17)*1)  /  T  );
revk(9)=kf/Kc*Y(2)*Y(17);

kf=kfarray(10);
fwdk(10)=kf*Y(3)*Y(13);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(13)*-1+g(18)*1)  /  T  );
revk(10)=kf/Kc*Y(2)*Y(18);

kf=kfarray(11);
fwdk(11)=kf*Y(3)*Y(14);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(13)*1+g(14)*-1)  /  T  );
revk(11)=kf/Kc*Y(5)*Y(13);

%lindemann approach
k0=6.020E+14*exp(-1.509650e+03/T);
kinf=kfarray(12);
Pr=(k0*(sumY+Y(1)*1+Y(4)*5+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*2.5+Y(27)*2+Y(49)*-0.5))/kinf;
F=1;
kf=kinf*(Pr/(1+Pr))*F;
fwdk(12)=kf*Y(3)*Y(15);
Kc=exp(   -(+g(3)*-1+g(15)*-1+g(16)*1)  /  T  )*(T/PATM);
revk(12)=kf/Kc*Y(16);

kf=kfarray(13);
fwdk(13)=kf*Y(3)*Y(17);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(15)*1+g(17)*-1)  /  T  );
revk(13)=kf/Kc*Y(5)*Y(15);

kf=kfarray(14);
fwdk(14)=kf*Y(3)*Y(17);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(16)*1+g(17)*-1)  /  T  );
revk(14)=kf/Kc*Y(2)*Y(16);

kf=kfarray(15);
fwdk(15)=kf*Y(3)*Y(18);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(17)*1+g(18)*-1)  /  T  );
revk(15)=kf/Kc*Y(5)*Y(17);

kf=kfarray(16);
fwdk(16)=kf*Y(3)*Y(19);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(18)*1+g(19)*-1)  /  T  );
revk(16)=kf/Kc*Y(5)*Y(18);

kf=kfarray(17);
fwdk(17)=kf*Y(3)*Y(20);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(18)*1+g(20)*-1)  /  T  );
revk(17)=kf/Kc*Y(5)*Y(18);

kf=kfarray(18);
fwdk(18)=kf*Y(3)*Y(21);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(19)*1+g(21)*-1)  /  T  );
revk(18)=kf/Kc*Y(5)*Y(19);

kf=kfarray(19);
fwdk(19)=kf*Y(3)*Y(21);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(20)*1+g(21)*-1)  /  T  );
revk(19)=kf/Kc*Y(5)*Y(20);

kf=kfarray(20);
fwdk(20)=kf*Y(3)*Y(22);
Kc=exp(   -(+g(3)*-1+g(10)*1+g(15)*1+g(22)*-1)  /  T  );
revk(20)=kf/Kc*Y(10)*Y(15);

kf=kfarray(21);
fwdk(21)=kf*Y(3)*Y(23);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(23)*-1+g(28)*1)  /  T  );
revk(21)=kf/Kc*Y(2)*Y(28);

kf=kfarray(22);
fwdk(22)=kf*Y(3)*Y(23);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(22)*1+g(23)*-1)  /  T  );
revk(22)=kf/Kc*Y(5)*Y(22);

kf=kfarray(23);
fwdk(23)=kf*Y(3)*Y(23);
Kc=exp(   -(+g(3)*-1+g(11)*1+g(15)*1+g(23)*-1)  /  T  );
revk(23)=kf/Kc*Y(11)*Y(15);

kf=kfarray(24);
fwdk(24)=kf*Y(3)*Y(24);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(24)*-1+g(29)*1)  /  T  );
revk(24)=kf/Kc*Y(2)*Y(29);

kf=kfarray(25);
fwdk(25)=kf*Y(3)*Y(25);
Kc=exp(   -(+g(3)*-1+g(13)*1+g(17)*1+g(25)*-1)  /  T  );
revk(25)=kf/Kc*Y(13)*Y(17);

kf=kfarray(26);
fwdk(26)=kf*Y(3)*Y(26);
Kc=exp(   -(+g(3)*-1+g(13)*1+g(18)*1+g(26)*-1)  /  T  );
revk(26)=kf/Kc*Y(13)*Y(18);

kf=kfarray(27);
fwdk(27)=kf*Y(3)*Y(27);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(26)*1+g(27)*-1)  /  T  );
revk(27)=kf/Kc*Y(5)*Y(26);

kf=kfarray(28);
fwdk(28)=kf*Y(3)*Y(28);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(15)*2+g(28)*-1)  /  T  )/(T/PATM);
revk(28)=kf/Kc*Y(2)*Y(15)*Y(15);

kf=kfarray(29);
fwdk(29)=kf*Y(3)*Y(29);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(28)*1+g(29)*-1)  /  T  );
revk(29)=kf/Kc*Y(5)*Y(28);

kf=kfarray(30);
fwdk(30)=kf*Y(3)*Y(29);
Kc=exp(   -(+g(3)*-1+g(11)*1+g(16)*1+g(29)*-1)  /  T  );
revk(30)=kf/Kc*Y(11)*Y(16);

kf=kfarray(31);
fwdk(31)=kf*Y(4)*Y(15);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(15)*-1+g(16)*1)  /  T  );
revk(31)=kf/Kc*Y(3)*Y(16);

kf=kfarray(32);
fwdk(32)=kf*Y(4)*Y(18);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(17)*1+g(18)*-1)  /  T  );
revk(32)=kf/Kc*Y(7)*Y(17);

kf=kfarray(33)*(sumY+Y(4)*-1+Y(6)*-1+Y(15)*-0.25+Y(16)*0.5+Y(27)*0.5+Y(48)*-1+Y(49)*-1);
fwdk(33)=kf*Y(2)*Y(4);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(7)*1)  /  T  )*(T/PATM);
revk(33)=kf/Kc*Y(7);

kf=kfarray(34);
fwdk(34)=kf*Y(2)*Y(4)*Y(4);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(7)*1)  /  T  )*(T/PATM);
revk(34)=kf/Kc*Y(4)*Y(7);

kf=kfarray(35);
fwdk(35)=kf*Y(2)*Y(4)*Y(6);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(7)*1)  /  T  )*(T/PATM);
revk(35)=kf/Kc*Y(6)*Y(7);

kf=kfarray(36);
fwdk(36)=kf*Y(2)*Y(4)*Y(48);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(7)*1)  /  T  )*(T/PATM);
revk(36)=kf/Kc*Y(7)*Y(48);

kf=kfarray(37);
fwdk(37)=kf*Y(2)*Y(4)*Y(49);
Kc=exp(   -(+g(2)*-1+g(4)*-1+g(7)*1)  /  T  )*(T/PATM);
revk(37)=kf/Kc*Y(7)*Y(49);

kf=kfarray(38);
fwdk(38)=kf*Y(2)*Y(4);
Kc=exp(   -(+g(2)*-1+g(3)*1+g(4)*-1+g(5)*1)  /  T  );
revk(38)=kf/Kc*Y(3)*Y(5);

kf=kfarray(39)*(sumY+Y(1)*-1+Y(6)*-1+Y(14)*1+Y(16)*-1+Y(27)*2+Y(49)*-0.37);
fwdk(39)=kf*Y(2)*Y(2);
Kc=exp(   -(+g(1)*1+g(2)*-2)  /  T  )*(T/PATM);
revk(39)=kf/Kc*Y(1);

kf=kfarray(40);
fwdk(40)=kf*Y(1)*Y(2)*Y(2);
Kc=exp(   -(+g(1)*1+g(2)*-2)  /  T  )*(T/PATM);
revk(40)=kf/Kc*Y(1)*Y(1);

kf=kfarray(41);
fwdk(41)=kf*Y(2)*Y(2)*Y(6);
Kc=exp(   -(+g(1)*1+g(2)*-2)  /  T  )*(T/PATM);
revk(41)=kf/Kc*Y(1)*Y(6);

kf=kfarray(42);
fwdk(42)=kf*Y(2)*Y(2)*Y(16);
Kc=exp(   -(+g(1)*1+g(2)*-2)  /  T  )*(T/PATM);
revk(42)=kf/Kc*Y(1)*Y(16);

kf=kfarray(43)*(sumY+Y(1)*-0.27+Y(6)*2.65+Y(14)*1+Y(27)*2+Y(49)*-0.62);
fwdk(43)=kf*Y(2)*Y(5);
Kc=exp(   -(+g(2)*-1+g(5)*-1+g(6)*1)  /  T  )*(T/PATM);
revk(43)=kf/Kc*Y(6);

kf=kfarray(44);
fwdk(44)=kf*Y(2)*Y(7);
Kc=exp(   -(+g(2)*-1+g(3)*1+g(6)*1+g(7)*-1)  /  T  );
revk(44)=kf/Kc*Y(3)*Y(6);

kf=kfarray(45);
fwdk(45)=kf*Y(2)*Y(7);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(4)*1+g(7)*-1)  /  T  );
revk(45)=kf/Kc*Y(1)*Y(4);

kf=kfarray(46);
fwdk(46)=kf*Y(2)*Y(7);
Kc=exp(   -(+g(2)*-1+g(5)*2+g(7)*-1)  /  T  );
revk(46)=kf/Kc*Y(5)*Y(5);

kf=kfarray(47);
fwdk(47)=kf*Y(2)*Y(8);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(7)*1+g(8)*-1)  /  T  );
revk(47)=kf/Kc*Y(1)*Y(7);

kf=kfarray(48);
fwdk(48)=kf*Y(2)*Y(8);
Kc=exp(   -(+g(2)*-1+g(5)*1+g(6)*1+g(8)*-1)  /  T  );
revk(48)=kf/Kc*Y(5)*Y(6);

kf=kfarray(49);
fwdk(49)=kf*Y(2)*Y(10);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(9)*1+g(10)*-1)  /  T  );
revk(49)=kf/Kc*Y(1)*Y(9);

%lindemann approach
k0=1.040E+26*T^-2.760*exp(-8.051467e+02/T);
kinf=kfarray(50);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.5620;%alpha
T3=91.00;%T***
T1=5836.00;%T*
T2=8552.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(50)=kf*Y(2)*Y(11);
Kc=exp(   -(+g(2)*-1+g(11)*-1+g(13)*1)  /  T  )*(T/PATM);
revk(50)=kf/Kc*Y(13);

kf=kfarray(51);
fwdk(51)=kf*Y(2)*Y(12);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(10)*1+g(12)*-1)  /  T  );
revk(51)=kf/Kc*Y(1)*Y(10);

%lindemann approach
k0=2.620E+33*T^-4.760*exp(-1.227849e+03/T);
kinf=kfarray(52);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*2+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.7830;%alpha
T3=74.00;%T***
T1=2941.00;%T*
T2=6964.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(52)=kf*Y(2)*Y(13);
Kc=exp(   -(+g(2)*-1+g(13)*-1+g(14)*1)  /  T  )*(T/PATM);
revk(52)=kf/Kc*Y(14);

kf=kfarray(53);
fwdk(53)=kf*Y(2)*Y(14);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(13)*1+g(14)*-1)  /  T  );
revk(53)=kf/Kc*Y(1)*Y(13);

%lindemann approach
k0=2.470E+24*T^-2.570*exp(-2.138671e+02/T);
kinf=kfarray(54);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.7824;%alpha
T3=271.00;%T***
T1=2755.00;%T*
T2=6570.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(54)=kf*Y(2)*Y(17);
Kc=exp(   -(+g(2)*-1+g(17)*-1+g(18)*1)  /  T  )*(T/PATM);
revk(54)=kf/Kc*Y(18);

kf=kfarray(55);
fwdk(55)=kf*Y(2)*Y(17);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(15)*1+g(17)*-1)  /  T  );
revk(55)=kf/Kc*Y(1)*Y(15);

%lindemann approach
k0=1.270E+32*T^-4.820*exp(-3.286005e+03/T);
kinf=kfarray(56);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2))/kinf;
%Troe form
a=.7187;%alpha
T3=103.00;%T***
T1=1291.00;%T*
T2=4160.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(56)=kf*Y(2)*Y(18);
Kc=exp(   -(+g(2)*-1+g(18)*-1+g(19)*1)  /  T  )*(T/PATM);
revk(56)=kf/Kc*Y(19);

%lindemann approach
k0=2.200E+30*T^-4.800*exp(-2.797885e+03/T);
kinf=kfarray(57);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2))/kinf;
%Troe form
a=.7580;%alpha
T3=94.00;%T***
T1=1555.00;%T*
T2=4200.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(57)=kf*Y(2)*Y(18);
Kc=exp(   -(+g(2)*-1+g(18)*-1+g(20)*1)  /  T  )*(T/PATM);
revk(57)=kf/Kc*Y(20);

kf=kfarray(58);
fwdk(58)=kf*Y(2)*Y(18);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(17)*1+g(18)*-1)  /  T  );
revk(58)=kf/Kc*Y(1)*Y(17);

%lindemann approach
k0=4.360E+31*T^-4.650*exp(-2.556341e+03/T);
kinf=kfarray(59);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2))/kinf;
%Troe form
a=.600;%alpha
T3=100.00;%T***
T1=90000.0;%T*
T2=10000.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(59)=kf*Y(2)*Y(19);
Kc=exp(   -(+g(2)*-1+g(19)*-1+g(21)*1)  /  T  )*(T/PATM);
revk(59)=kf/Kc*Y(21);

kf=kfarray(60);
fwdk(60)=kf*Y(2)*Y(19);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(18)*1+g(19)*-1)  /  T  );
revk(60)=kf/Kc*Y(1)*Y(18);

kf=kfarray(61);
fwdk(61)=kf*Y(2)*Y(19);
Kc=exp(   -(+g(2)*-1+g(5)*1+g(13)*1+g(19)*-1)  /  T  );
revk(61)=kf/Kc*Y(5)*Y(13);

kf=kfarray(62);
fwdk(62)=kf*Y(2)*Y(19);
Kc=exp(   -(+g(2)*-1+g(6)*1+g(12)*1+g(19)*-1)  /  T  );
revk(62)=kf/Kc*Y(6)*Y(12);

%lindemann approach
k0=4.660E+41*T^-7.440*exp(-7.085291e+03/T);
kinf=kfarray(63);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2))/kinf;
%Troe form
a=.700;%alpha
T3=100.00;%T***
T1=90000.0;%T*
T2=10000.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(63)=kf*Y(2)*Y(20);
Kc=exp(   -(+g(2)*-1+g(20)*-1+g(21)*1)  /  T  )*(T/PATM);
revk(63)=kf/Kc*Y(21);

kf=kfarray(64);
fwdk(64)=kf*Y(2)*Y(20);
Kc=exp(   -(+g(19)*1+g(20)*-1)  /  T  );
revk(64)=kf/Kc*Y(2)*Y(19);

kf=kfarray(65);
fwdk(65)=kf*Y(2)*Y(20);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(18)*1+g(20)*-1)  /  T  );
revk(65)=kf/Kc*Y(1)*Y(18);

kf=kfarray(66);
fwdk(66)=kf*Y(2)*Y(20);
Kc=exp(   -(+g(2)*-1+g(5)*1+g(13)*1+g(20)*-1)  /  T  );
revk(66)=kf/Kc*Y(5)*Y(13);

kf=kfarray(67);
fwdk(67)=kf*Y(2)*Y(20);
Kc=exp(   -(+g(2)*-1+g(6)*1+g(12)*1+g(20)*-1)  /  T  );
revk(67)=kf/Kc*Y(6)*Y(12);

kf=kfarray(68);
fwdk(68)=kf*Y(2)*Y(21);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(19)*1+g(21)*-1)  /  T  );
revk(68)=kf/Kc*Y(1)*Y(19);

kf=kfarray(69);
fwdk(69)=kf*Y(2)*Y(21);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(20)*1+g(21)*-1)  /  T  );
revk(69)=kf/Kc*Y(1)*Y(20);

%lindemann approach
k0=3.750E+33*T^-4.800*exp(-9.561117e+02/T);
kinf=kfarray(70);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.6464;%alpha
T3=132.00;%T***
T1=1315.00;%T*
T2=5566.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(70)=kf*Y(2)*Y(22);
Kc=exp(   -(+g(2)*-1+g(22)*-1+g(23)*1)  /  T  )*(T/PATM);
revk(70)=kf/Kc*Y(23);

%lindemann approach
k0=3.800E+40*T^-7.270*exp(-3.633224e+03/T);
kinf=kfarray(71);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.7507;%alpha
T3=98.50;%T***
T1=1302.00;%T*
T2=4167.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(71)=kf*Y(2)*Y(23);
Kc=exp(   -(+g(2)*-1+g(23)*-1+g(24)*1)  /  T  )*(T/PATM);
revk(71)=kf/Kc*Y(24);

%lindemann approach
k0=1.400E+30*T^-3.860*exp(-1.670679e+03/T);
kinf=kfarray(72);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.7820;%alpha
T3=207.50;%T***
T1=2663.00;%T*
T2=6095.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(72)=kf*Y(2)*Y(24);
Kc=exp(   -(+g(2)*-1+g(24)*-1+g(25)*1)  /  T  )*(T/PATM);
revk(72)=kf/Kc*Y(25);

kf=kfarray(73);
fwdk(73)=kf*Y(2)*Y(24);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(23)*1+g(24)*-1)  /  T  );
revk(73)=kf/Kc*Y(1)*Y(23);

%lindemann approach
k0=0.600E+42*T^-7.620*exp(-3.507420e+03/T);
kinf=kfarray(74);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.9753;%alpha
T3=210.00;%T***
T1=984.00;%T*
T2=4374.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(74)=kf*Y(2)*Y(25);
Kc=exp(   -(+g(2)*-1+g(25)*-1+g(26)*1)  /  T  )*(T/PATM);
revk(74)=kf/Kc*Y(26);

kf=kfarray(75);
fwdk(75)=kf*Y(2)*Y(25);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(24)*1+g(25)*-1)  /  T  );
revk(75)=kf/Kc*Y(1)*Y(24);

%lindemann approach
k0=1.990E+41*T^-7.080*exp(-3.364003e+03/T);
kinf=kfarray(76);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.8422;%alpha
T3=125.00;%T***
T1=2219.00;%T*
T2=6882.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(76)=kf*Y(2)*Y(26);
Kc=exp(   -(+g(2)*-1+g(26)*-1+g(27)*1)  /  T  )*(T/PATM);
revk(76)=kf/Kc*Y(27);

kf=kfarray(77);
fwdk(77)=kf*Y(2)*Y(26);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(25)*1+g(26)*-1)  /  T  );
revk(77)=kf/Kc*Y(1)*Y(25);

kf=kfarray(78);
fwdk(78)=kf*Y(2)*Y(27);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(26)*1+g(27)*-1)  /  T  );
revk(78)=kf/Kc*Y(1)*Y(26);

kf=kfarray(79);
fwdk(79)=kf*Y(2)*Y(28);
Kc=exp(   -(+g(2)*-1+g(12)*1+g(15)*1+g(28)*-1)  /  T  );
revk(79)=kf/Kc*Y(12)*Y(15);

kf=kfarray(80);
fwdk(80)=kf*Y(2)*Y(29);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(28)*1+g(29)*-1)  /  T  );
revk(80)=kf/Kc*Y(1)*Y(28);

kf=kfarray(81);
fwdk(81)=kf*Y(2)*Y(29);
Kc=exp(   -(+g(2)*-1+g(13)*1+g(15)*1+g(29)*-1)  /  T  );
revk(81)=kf/Kc*Y(13)*Y(15);

kf=kfarray(82);
fwdk(82)=kf*Y(2)*Y(30);
Kc=exp(   -(+g(29)*1+g(30)*-1)  /  T  );
revk(82)=kf/Kc*Y(2)*Y(29);

%lindemann approach
k0=5.070E+27*T^-3.420*exp(-4.244633e+04/T);
kinf=kfarray(83);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.9320;%alpha
T3=197.00;%T***
T1=1540.00;%T*
T2=10300.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(83)=kf*Y(1)*Y(15);
Kc=exp(   -(+g(1)*-1+g(15)*-1+g(18)*1)  /  T  )*(T/PATM);
revk(83)=kf/Kc*Y(18);

kf=kfarray(84);
fwdk(84)=kf*Y(1)*Y(5);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(5)*-1+g(6)*1)  /  T  );
revk(84)=kf/Kc*Y(2)*Y(6);

%lindemann approach
k0=2.300E+18*T^-.900*exp(8.554683e+02/T);
kinf=kfarray(85);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.7346;%alpha
T3=94.00;%T***
T1=1756.00;%T*
T2=5182.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(85)=kf*Y(5)*Y(5);
Kc=exp(   -(+g(5)*-2+g(8)*1)  /  T  )*(T/PATM);
revk(85)=kf/Kc*Y(8);

kf=kfarray(86);
fwdk(86)=kf*Y(5)*Y(5);
Kc=exp(   -(+g(3)*1+g(5)*-2+g(6)*1)  /  T  );
revk(86)=kf/Kc*Y(3)*Y(6);

kf=kfarray(87);
fwdk(87)=kf*Y(5)*Y(7);
Kc=exp(   -(+g(4)*1+g(5)*-1+g(6)*1+g(7)*-1)  /  T  );
revk(87)=kf/Kc*Y(4)*Y(6);

kf=kfarray(88);
fwdk(88)=kf*Y(5)*Y(8);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(7)*1+g(8)*-1)  /  T  );
revk(88)=kf/Kc*Y(6)*Y(7);

kf=kfarray(89);
fwdk(89)=kf*Y(5)*Y(8);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(7)*1+g(8)*-1)  /  T  );
revk(89)=kf/Kc*Y(6)*Y(7);

kf=kfarray(90);
fwdk(90)=kf*Y(5)*Y(9);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(9)*-1+g(15)*1)  /  T  );
revk(90)=kf/Kc*Y(2)*Y(15);

kf=kfarray(91);
fwdk(91)=kf*Y(5)*Y(10);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(10)*-1+g(17)*1)  /  T  );
revk(91)=kf/Kc*Y(2)*Y(17);

kf=kfarray(92);
fwdk(92)=kf*Y(5)*Y(11);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(11)*-1+g(18)*1)  /  T  );
revk(92)=kf/Kc*Y(2)*Y(18);

kf=kfarray(93);
fwdk(93)=kf*Y(5)*Y(11);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(10)*1+g(11)*-1)  /  T  );
revk(93)=kf/Kc*Y(6)*Y(10);

kf=kfarray(94);
fwdk(94)=kf*Y(5)*Y(12);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(12)*-1+g(18)*1)  /  T  );
revk(94)=kf/Kc*Y(2)*Y(18);

%lindemann approach
k0=4.000E+36*T^-5.920*exp(-1.580100e+03/T);
kinf=kfarray(95);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2))/kinf;
%Troe form
a=.4120;%alpha
T3=195.0;%T***
T1=5900.00;%T*
T2=6394.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(95)=kf*Y(5)*Y(13);
Kc=exp(   -(+g(5)*-1+g(13)*-1+g(21)*1)  /  T  )*(T/PATM);
revk(95)=kf/Kc*Y(21);

kf=kfarray(96);
fwdk(96)=kf*Y(5)*Y(13);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(11)*1+g(13)*-1)  /  T  );
revk(96)=kf/Kc*Y(6)*Y(11);

kf=kfarray(97);
fwdk(97)=kf*Y(5)*Y(13);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(12)*1+g(13)*-1)  /  T  );
revk(97)=kf/Kc*Y(6)*Y(12);

kf=kfarray(98);
fwdk(98)=kf*Y(5)*Y(14);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(13)*1+g(14)*-1)  /  T  );
revk(98)=kf/Kc*Y(6)*Y(13);

kf=kfarray(99);
fwdk(99)=kf*Y(5)*Y(15);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(15)*-1+g(16)*1)  /  T  );
revk(99)=kf/Kc*Y(2)*Y(16);

kf=kfarray(100);
fwdk(100)=kf*Y(5)*Y(17);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(15)*1+g(17)*-1)  /  T  );
revk(100)=kf/Kc*Y(6)*Y(15);

kf=kfarray(101);
fwdk(101)=kf*Y(5)*Y(18);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(17)*1+g(18)*-1)  /  T  );
revk(101)=kf/Kc*Y(6)*Y(17);

kf=kfarray(102);
fwdk(102)=kf*Y(5)*Y(19);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(18)*1+g(19)*-1)  /  T  );
revk(102)=kf/Kc*Y(6)*Y(18);

kf=kfarray(103);
fwdk(103)=kf*Y(5)*Y(20);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(18)*1+g(20)*-1)  /  T  );
revk(103)=kf/Kc*Y(6)*Y(18);

kf=kfarray(104);
fwdk(104)=kf*Y(5)*Y(21);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(19)*1+g(21)*-1)  /  T  );
revk(104)=kf/Kc*Y(6)*Y(19);

kf=kfarray(105);
fwdk(105)=kf*Y(5)*Y(21);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(20)*1+g(21)*-1)  /  T  );
revk(105)=kf/Kc*Y(6)*Y(20);

kf=kfarray(106);
fwdk(106)=kf*Y(5)*Y(22);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(22)*-1+g(28)*1)  /  T  );
revk(106)=kf/Kc*Y(2)*Y(28);

kf=kfarray(107);
fwdk(107)=kf*Y(5)*Y(23);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(23)*-1+g(29)*1)  /  T  );
revk(107)=kf/Kc*Y(2)*Y(29);

kf=kfarray(108);
fwdk(108)=kf*Y(5)*Y(23);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(23)*-1+g(30)*1)  /  T  );
revk(108)=kf/Kc*Y(2)*Y(30);

kf=kfarray(109);
fwdk(109)=kf*Y(5)*Y(23);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(22)*1+g(23)*-1)  /  T  );
revk(109)=kf/Kc*Y(6)*Y(22);

kf=kfarray(110);
fwdk(110)=kf*Y(5)*Y(23);
Kc=exp(   -(+g(5)*-1+g(13)*1+g(15)*1+g(23)*-1)  /  T  );
revk(110)=kf/Kc*Y(13)*Y(15);

kf=kfarray(111);
fwdk(111)=kf*Y(5)*Y(24);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(23)*1+g(24)*-1)  /  T  );
revk(111)=kf/Kc*Y(6)*Y(23);

kf=kfarray(112);
fwdk(112)=kf*Y(5)*Y(25);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(24)*1+g(25)*-1)  /  T  );
revk(112)=kf/Kc*Y(6)*Y(24);

kf=kfarray(113);
fwdk(113)=kf*Y(5)*Y(27);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(26)*1+g(27)*-1)  /  T  );
revk(113)=kf/Kc*Y(6)*Y(26);

kf=kfarray(114);
fwdk(114)=kf*Y(5)*Y(29);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(28)*1+g(29)*-1)  /  T  );
revk(114)=kf/Kc*Y(6)*Y(28);

kf=kfarray(115);
fwdk(115)=kf*Y(7)*Y(7);
Kc=exp(   -(+g(4)*1+g(7)*-2+g(8)*1)  /  T  );
revk(115)=kf/Kc*Y(4)*Y(8);

kf=kfarray(116);
fwdk(116)=kf*Y(7)*Y(7);
Kc=exp(   -(+g(4)*1+g(7)*-2+g(8)*1)  /  T  );
revk(116)=kf/Kc*Y(4)*Y(8);

kf=kfarray(117);
fwdk(117)=kf*Y(7)*Y(11);
Kc=exp(   -(+g(5)*1+g(7)*-1+g(11)*-1+g(18)*1)  /  T  );
revk(117)=kf/Kc*Y(5)*Y(18);

kf=kfarray(118);
fwdk(118)=kf*Y(7)*Y(13);
Kc=exp(   -(+g(4)*1+g(7)*-1+g(13)*-1+g(14)*1)  /  T  );
revk(118)=kf/Kc*Y(4)*Y(14);

kf=kfarray(119);
fwdk(119)=kf*Y(7)*Y(13);
Kc=exp(   -(+g(5)*1+g(7)*-1+g(13)*-1+g(20)*1)  /  T  );
revk(119)=kf/Kc*Y(5)*Y(20);

kf=kfarray(120);
fwdk(120)=kf*Y(7)*Y(15);
Kc=exp(   -(+g(5)*1+g(7)*-1+g(15)*-1+g(16)*1)  /  T  );
revk(120)=kf/Kc*Y(5)*Y(16);

kf=kfarray(121);
fwdk(121)=kf*Y(7)*Y(18);
Kc=exp(   -(+g(7)*-1+g(8)*1+g(17)*1+g(18)*-1)  /  T  );
revk(121)=kf/Kc*Y(8)*Y(17);

kf=kfarray(122);
fwdk(122)=kf*Y(4)*Y(9);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(9)*-1+g(15)*1)  /  T  );
revk(122)=kf/Kc*Y(3)*Y(15);

kf=kfarray(123);
fwdk(123)=kf*Y(9)*Y(11);
Kc=exp(   -(+g(2)*1+g(9)*-1+g(11)*-1+g(22)*1)  /  T  );
revk(123)=kf/Kc*Y(2)*Y(22);

kf=kfarray(124);
fwdk(124)=kf*Y(9)*Y(13);
Kc=exp(   -(+g(2)*1+g(9)*-1+g(13)*-1+g(23)*1)  /  T  );
revk(124)=kf/Kc*Y(2)*Y(23);

kf=kfarray(125);
fwdk(125)=kf*Y(4)*Y(10);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(10)*-1+g(17)*1)  /  T  );
revk(125)=kf/Kc*Y(3)*Y(17);

kf=kfarray(126);
fwdk(126)=kf*Y(1)*Y(10);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(10)*-1+g(11)*1)  /  T  );
revk(126)=kf/Kc*Y(2)*Y(11);

kf=kfarray(127);
fwdk(127)=kf*Y(6)*Y(10);
Kc=exp(   -(+g(2)*1+g(6)*-1+g(10)*-1+g(18)*1)  /  T  );
revk(127)=kf/Kc*Y(2)*Y(18);

kf=kfarray(128);
fwdk(128)=kf*Y(10)*Y(11);
Kc=exp(   -(+g(2)*1+g(10)*-1+g(11)*-1+g(23)*1)  /  T  );
revk(128)=kf/Kc*Y(2)*Y(23);

kf=kfarray(129);
fwdk(129)=kf*Y(10)*Y(13);
Kc=exp(   -(+g(2)*1+g(10)*-1+g(13)*-1+g(24)*1)  /  T  );
revk(129)=kf/Kc*Y(2)*Y(24);

kf=kfarray(130);
fwdk(130)=kf*Y(10)*Y(14);
Kc=exp(   -(+g(2)*1+g(10)*-1+g(14)*-1+g(25)*1)  /  T  );
revk(130)=kf/Kc*Y(2)*Y(25);

%lindemann approach
k0=2.690E+28*T^-3.740*exp(-9.742275e+02/T);
kinf=kfarray(131);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.5757;%alpha
T3=237.00;%T***
T1=1652.00;%T*
T2=5069.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(131)=kf*Y(10)*Y(15);
Kc=exp(   -(+g(10)*-1+g(15)*-1+g(28)*1)  /  T  )*(T/PATM);
revk(131)=kf/Kc*Y(28);

kf=kfarray(132);
fwdk(132)=kf*Y(10)*Y(16);
Kc=exp(   -(+g(10)*-1+g(15)*1+g(16)*-1+g(17)*1)  /  T  );
revk(132)=kf/Kc*Y(15)*Y(17);

kf=kfarray(133);
fwdk(133)=kf*Y(10)*Y(18);
Kc=exp(   -(+g(2)*1+g(10)*-1+g(18)*-1+g(29)*1)  /  T  );
revk(133)=kf/Kc*Y(2)*Y(29);

kf=kfarray(134);
fwdk(134)=kf*Y(10)*Y(28);
Kc=exp(   -(+g(10)*-1+g(15)*1+g(23)*1+g(28)*-1)  /  T  );
revk(134)=kf/Kc*Y(15)*Y(23);

kf=kfarray(135);
fwdk(135)=kf*Y(4)*Y(11);

kf=kfarray(136);
fwdk(136)=kf*Y(1)*Y(11);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(11)*-1+g(13)*1)  /  T  );
revk(136)=kf/Kc*Y(2)*Y(13);

kf=kfarray(137);
fwdk(137)=kf*Y(11)*Y(11);
Kc=exp(   -(+g(1)*1+g(11)*-2+g(23)*1)  /  T  );
revk(137)=kf/Kc*Y(1)*Y(23);

kf=kfarray(138);
fwdk(138)=kf*Y(11)*Y(13);
Kc=exp(   -(+g(2)*1+g(11)*-1+g(13)*-1+g(25)*1)  /  T  );
revk(138)=kf/Kc*Y(2)*Y(25);

kf=kfarray(139);
fwdk(139)=kf*Y(11)*Y(14);
Kc=exp(   -(+g(11)*-1+g(13)*2+g(14)*-1)  /  T  );
revk(139)=kf/Kc*Y(13)*Y(13);

%lindemann approach
k0=2.690E+33*T^-5.110*exp(-3.570322e+03/T);
kinf=kfarray(140);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.5907;%alpha
T3=275.00;%T***
T1=1226.00;%T*
T2=5185.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(140)=kf*Y(11)*Y(15);
Kc=exp(   -(+g(11)*-1+g(15)*-1+g(29)*1)  /  T  )*(T/PATM);
revk(140)=kf/Kc*Y(29);

kf=kfarray(141);
fwdk(141)=kf*Y(11)*Y(28);
Kc=exp(   -(+g(11)*-1+g(15)*1+g(24)*1+g(28)*-1)  /  T  );
revk(141)=kf/Kc*Y(15)*Y(24);

kf=kfarray(142);
fwdk(142)=kf*Y(12)*Y(48);
Kc=exp(   -(+g(11)*1+g(12)*-1)  /  T  );
revk(142)=kf/Kc*Y(11)*Y(48);

kf=kfarray(143);
fwdk(143)=kf*Y(12)*Y(49);
Kc=exp(   -(+g(11)*1+g(12)*-1)  /  T  );
revk(143)=kf/Kc*Y(11)*Y(49);

kf=kfarray(144);
fwdk(144)=kf*Y(4)*Y(12);
Kc=exp(   -(+g(2)*1+g(4)*-1+g(5)*1+g(12)*-1+g(15)*1)  /  T  )/(T/PATM);
revk(144)=kf/Kc*Y(2)*Y(5)*Y(15);

kf=kfarray(145);
fwdk(145)=kf*Y(4)*Y(12);
Kc=exp(   -(+g(4)*-1+g(6)*1+g(12)*-1+g(15)*1)  /  T  );
revk(145)=kf/Kc*Y(6)*Y(15);

kf=kfarray(146);
fwdk(146)=kf*Y(1)*Y(12);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(12)*-1+g(13)*1)  /  T  );
revk(146)=kf/Kc*Y(2)*Y(13);

%lindemann approach
k0=1.880E+38*T^-6.360*exp(-2.536212e+03/T);
kinf=kfarray(147);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2))/kinf;
%Troe form
a=.6027;%alpha
T3=208.00;%T***
T1=3922.00;%T*
T2=10180.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(147)=kf*Y(6)*Y(12);
Kc=exp(   -(+g(6)*-1+g(12)*-1+g(21)*1)  /  T  )*(T/PATM);
revk(147)=kf/Kc*Y(21);

kf=kfarray(148);
fwdk(148)=kf*Y(6)*Y(12);
Kc=exp(   -(+g(11)*1+g(12)*-1)  /  T  );
revk(148)=kf/Kc*Y(6)*Y(11);

kf=kfarray(149);
fwdk(149)=kf*Y(12)*Y(13);
Kc=exp(   -(+g(2)*1+g(12)*-1+g(13)*-1+g(25)*1)  /  T  );
revk(149)=kf/Kc*Y(2)*Y(25);

kf=kfarray(150);
fwdk(150)=kf*Y(12)*Y(14);
Kc=exp(   -(+g(12)*-1+g(13)*2+g(14)*-1)  /  T  );
revk(150)=kf/Kc*Y(13)*Y(13);

kf=kfarray(151);
fwdk(151)=kf*Y(12)*Y(15);
Kc=exp(   -(+g(11)*1+g(12)*-1)  /  T  );
revk(151)=kf/Kc*Y(11)*Y(15);

kf=kfarray(152);
fwdk(152)=kf*Y(12)*Y(16);
Kc=exp(   -(+g(11)*1+g(12)*-1)  /  T  );
revk(152)=kf/Kc*Y(11)*Y(16);

kf=kfarray(153);
fwdk(153)=kf*Y(12)*Y(16);
Kc=exp(   -(+g(12)*-1+g(15)*1+g(16)*-1+g(18)*1)  /  T  );
revk(153)=kf/Kc*Y(15)*Y(18);

kf=kfarray(154);
fwdk(154)=kf*Y(12)*Y(27);
Kc=exp(   -(+g(12)*-1+g(13)*1+g(26)*1+g(27)*-1)  /  T  );
revk(154)=kf/Kc*Y(13)*Y(26);

kf=kfarray(155);
fwdk(155)=kf*Y(4)*Y(13);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(13)*-1+g(20)*1)  /  T  );
revk(155)=kf/Kc*Y(3)*Y(20);

kf=kfarray(156);
fwdk(156)=kf*Y(4)*Y(13);
Kc=exp(   -(+g(4)*-1+g(5)*1+g(13)*-1+g(18)*1)  /  T  );
revk(156)=kf/Kc*Y(5)*Y(18);

kf=kfarray(157);
fwdk(157)=kf*Y(8)*Y(13);
Kc=exp(   -(+g(7)*1+g(8)*-1+g(13)*-1+g(14)*1)  /  T  );
revk(157)=kf/Kc*Y(7)*Y(14);

%lindemann approach
k0=3.400E+41*T^-7.030*exp(-1.389884e+03/T);
kinf=kfarray(158);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.6190;%alpha
T3=73.20;%T***
T1=1180.00;%T*
T2=9999.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(158)=kf*Y(13)*Y(13);
Kc=exp(   -(+g(13)*-2+g(27)*1)  /  T  )*(T/PATM);
revk(158)=kf/Kc*Y(27);

kf=kfarray(159);
fwdk(159)=kf*Y(13)*Y(13);
Kc=exp(   -(+g(2)*1+g(13)*-2+g(26)*1)  /  T  );
revk(159)=kf/Kc*Y(2)*Y(26);

kf=kfarray(160);
fwdk(160)=kf*Y(13)*Y(17);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(15)*1+g(17)*-1)  /  T  );
revk(160)=kf/Kc*Y(14)*Y(15);

kf=kfarray(161);
fwdk(161)=kf*Y(13)*Y(18);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(17)*1+g(18)*-1)  /  T  );
revk(161)=kf/Kc*Y(14)*Y(17);

kf=kfarray(162);
fwdk(162)=kf*Y(13)*Y(21);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(19)*1+g(21)*-1)  /  T  );
revk(162)=kf/Kc*Y(14)*Y(19);

kf=kfarray(163);
fwdk(163)=kf*Y(13)*Y(21);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(20)*1+g(21)*-1)  /  T  );
revk(163)=kf/Kc*Y(14)*Y(20);

kf=kfarray(164);
fwdk(164)=kf*Y(13)*Y(25);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(24)*1+g(25)*-1)  /  T  );
revk(164)=kf/Kc*Y(14)*Y(24);

kf=kfarray(165);
fwdk(165)=kf*Y(13)*Y(27);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(26)*1+g(27)*-1)  /  T  );
revk(165)=kf/Kc*Y(14)*Y(26);

kf=kfarray(166);
fwdk(166)=kf*Y(6)*Y(17);
Kc=exp(   -(+g(2)*1+g(15)*1+g(17)*-1)  /  T  )/(T/PATM);
revk(166)=kf/Kc*Y(2)*Y(6)*Y(15);

kf=kfarray(167)*(sumY+Y(1)*1+Y(6)*-1+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2);
fwdk(167)=kf*Y(17);
Kc=exp(   -(+g(2)*1+g(15)*1+g(17)*-1)  /  T  )/(T/PATM);
revk(167)=kf/Kc*Y(2)*Y(15);

kf=kfarray(168);
fwdk(168)=kf*Y(4)*Y(17);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(15)*1+g(17)*-1)  /  T  );
revk(168)=kf/Kc*Y(7)*Y(15);

kf=kfarray(169);
fwdk(169)=kf*Y(4)*Y(19);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(18)*1+g(19)*-1)  /  T  );
revk(169)=kf/Kc*Y(7)*Y(18);

kf=kfarray(170);
fwdk(170)=kf*Y(4)*Y(20);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(18)*1+g(20)*-1)  /  T  );
revk(170)=kf/Kc*Y(7)*Y(18);

kf=kfarray(171);
fwdk(171)=kf*Y(4)*Y(22);
Kc=exp(   -(+g(4)*-1+g(15)*1+g(17)*1+g(22)*-1)  /  T  );
revk(171)=kf/Kc*Y(15)*Y(17);

kf=kfarray(172);
fwdk(172)=kf*Y(1)*Y(22);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(22)*-1+g(23)*1)  /  T  );
revk(172)=kf/Kc*Y(2)*Y(23);

kf=kfarray(173);
fwdk(173)=kf*Y(4)*Y(24);
Kc=exp(   -(+g(4)*-1+g(17)*1+g(18)*1+g(24)*-1)  /  T  );
revk(173)=kf/Kc*Y(17)*Y(18);

%lindemann approach
k0=1.580E+51*T^-9.300*exp(-4.921459e+04/T);
kinf=kfarray(174);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.7345;%alpha
T3=180.00;%T***
T1=1035.00;%T*
T2=5417.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(174)=kf*Y(25);
Kc=exp(   -(+g(1)*1+g(23)*1+g(25)*-1)  /  T  )/(T/PATM);
revk(174)=kf/Kc*Y(1)*Y(23);

kf=kfarray(175);
fwdk(175)=kf*Y(4)*Y(26);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(25)*1+g(26)*-1)  /  T  );
revk(175)=kf/Kc*Y(7)*Y(25);

kf=kfarray(176);
fwdk(176)=kf*Y(4)*Y(28);
Kc=exp(   -(+g(4)*-1+g(5)*1+g(15)*2+g(28)*-1)  /  T  )/(T/PATM);
revk(176)=kf/Kc*Y(5)*Y(15)*Y(15);

kf=kfarray(177);
fwdk(177)=kf*Y(28)*Y(28);
Kc=exp(   -(+g(15)*2+g(23)*1+g(28)*-2)  /  T  )/(T/PATM);
revk(177)=kf/Kc*Y(15)*Y(15)*Y(23);

kf=kfarray(178);
fwdk(178)=kf*Y(31)*Y(36);
Kc=exp(   -(+g(3)*1+g(31)*-1+g(36)*-1+g(48)*1)  /  T  );
revk(178)=kf/Kc*Y(3)*Y(48);

kf=kfarray(179);
fwdk(179)=kf*Y(4)*Y(31);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(31)*-1+g(36)*1)  /  T  );
revk(179)=kf/Kc*Y(3)*Y(36);

kf=kfarray(180);
fwdk(180)=kf*Y(5)*Y(31);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(31)*-1+g(36)*1)  /  T  );
revk(180)=kf/Kc*Y(2)*Y(36);

kf=kfarray(181);
fwdk(181)=kf*Y(3)*Y(38);
Kc=exp(   -(+g(3)*-1+g(4)*1+g(38)*-1+g(48)*1)  /  T  );
revk(181)=kf/Kc*Y(4)*Y(48);

kf=kfarray(182);
fwdk(182)=kf*Y(3)*Y(38);
Kc=exp(   -(+g(3)*-1+g(36)*2+g(38)*-1)  /  T  );
revk(182)=kf/Kc*Y(36)*Y(36);

kf=kfarray(183);
fwdk(183)=kf*Y(2)*Y(38);
Kc=exp(   -(+g(2)*-1+g(5)*1+g(38)*-1+g(48)*1)  /  T  );
revk(183)=kf/Kc*Y(5)*Y(48);

kf=kfarray(184);
fwdk(184)=kf*Y(5)*Y(38);
Kc=exp(   -(+g(5)*-1+g(7)*1+g(38)*-1+g(48)*1)  /  T  );
revk(184)=kf/Kc*Y(7)*Y(48);

%lindemann approach
k0=6.370E+14*exp(-2.850219e+04/T);
kinf=kfarray(185);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.375))/kinf;
F=1;
kf=kinf*(Pr/(1+Pr))*F;
fwdk(185)=kf*Y(38);
Kc=exp(   -(+g(3)*1+g(38)*-1+g(48)*1)  /  T  )/(T/PATM);
revk(185)=kf/Kc*Y(3)*Y(48);

kf=kfarray(186);
fwdk(186)=kf*Y(7)*Y(36);
Kc=exp(   -(+g(5)*1+g(7)*-1+g(36)*-1+g(37)*1)  /  T  );
revk(186)=kf/Kc*Y(5)*Y(37);

kf=kfarray(187)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(187)=kf*Y(3)*Y(36);
Kc=exp(   -(+g(3)*-1+g(36)*-1+g(37)*1)  /  T  )*(T/PATM);
revk(187)=kf/Kc*Y(37);

kf=kfarray(188);
fwdk(188)=kf*Y(3)*Y(37);
Kc=exp(   -(+g(3)*-1+g(4)*1+g(36)*1+g(37)*-1)  /  T  );
revk(188)=kf/Kc*Y(4)*Y(36);

kf=kfarray(189);
fwdk(189)=kf*Y(2)*Y(37);
Kc=exp(   -(+g(2)*-1+g(5)*1+g(36)*1+g(37)*-1)  /  T  );
revk(189)=kf/Kc*Y(5)*Y(36);

kf=kfarray(190);
fwdk(190)=kf*Y(3)*Y(32);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(32)*-1+g(36)*1)  /  T  );
revk(190)=kf/Kc*Y(2)*Y(36);

kf=kfarray(191);
fwdk(191)=kf*Y(2)*Y(32);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(31)*1+g(32)*-1)  /  T  );
revk(191)=kf/Kc*Y(1)*Y(31);

kf=kfarray(192);
fwdk(192)=kf*Y(5)*Y(32);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(32)*-1+g(39)*1)  /  T  );
revk(192)=kf/Kc*Y(2)*Y(39);

kf=kfarray(193);
fwdk(193)=kf*Y(5)*Y(32);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(31)*1+g(32)*-1)  /  T  );
revk(193)=kf/Kc*Y(6)*Y(31);

kf=kfarray(194);
fwdk(194)=kf*Y(4)*Y(32);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(32)*-1+g(39)*1)  /  T  );
revk(194)=kf/Kc*Y(3)*Y(39);

kf=kfarray(195);
fwdk(195)=kf*Y(4)*Y(32);
Kc=exp(   -(+g(4)*-1+g(5)*1+g(32)*-1+g(36)*1)  /  T  );
revk(195)=kf/Kc*Y(5)*Y(36);

kf=kfarray(196);
fwdk(196)=kf*Y(31)*Y(32);
Kc=exp(   -(+g(2)*1+g(31)*-1+g(32)*-1+g(48)*1)  /  T  );
revk(196)=kf/Kc*Y(2)*Y(48);

kf=kfarray(197);
fwdk(197)=kf*Y(6)*Y(32);
Kc=exp(   -(+g(1)*1+g(6)*-1+g(32)*-1+g(39)*1)  /  T  );
revk(197)=kf/Kc*Y(1)*Y(39);

kf=kfarray(198);
fwdk(198)=kf*Y(32)*Y(36);
Kc=exp(   -(+g(5)*1+g(32)*-1+g(36)*-1+g(48)*1)  /  T  );
revk(198)=kf/Kc*Y(5)*Y(48);

kf=kfarray(199);
fwdk(199)=kf*Y(32)*Y(36);
Kc=exp(   -(+g(2)*1+g(32)*-1+g(36)*-1+g(38)*1)  /  T  );
revk(199)=kf/Kc*Y(2)*Y(38);

kf=kfarray(200);
fwdk(200)=kf*Y(3)*Y(33);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(32)*1+g(33)*-1)  /  T  );
revk(200)=kf/Kc*Y(5)*Y(32);

kf=kfarray(201);
fwdk(201)=kf*Y(3)*Y(33);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(33)*-1+g(39)*1)  /  T  );
revk(201)=kf/Kc*Y(2)*Y(39);

kf=kfarray(202);
fwdk(202)=kf*Y(2)*Y(33);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(32)*1+g(33)*-1)  /  T  );
revk(202)=kf/Kc*Y(1)*Y(32);

kf=kfarray(203);
fwdk(203)=kf*Y(5)*Y(33);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(32)*1+g(33)*-1)  /  T  );
revk(203)=kf/Kc*Y(6)*Y(32);

kf=kfarray(204);
fwdk(204)=kf*Y(35);
Kc=exp(   -(+g(2)*1+g(35)*-1+g(48)*1)  /  T  )/(T/PATM);
revk(204)=kf/Kc*Y(2)*Y(48);

kf=kfarray(205)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(205)=kf*Y(35);
Kc=exp(   -(+g(2)*1+g(35)*-1+g(48)*1)  /  T  )/(T/PATM);
revk(205)=kf/Kc*Y(2)*Y(48);

kf=kfarray(206);
fwdk(206)=kf*Y(4)*Y(35);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(35)*-1+g(48)*1)  /  T  );
revk(206)=kf/Kc*Y(7)*Y(48);

kf=kfarray(207);
fwdk(207)=kf*Y(3)*Y(35);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(35)*-1+g(48)*1)  /  T  );
revk(207)=kf/Kc*Y(5)*Y(48);

kf=kfarray(208);
fwdk(208)=kf*Y(3)*Y(35);
Kc=exp(   -(+g(3)*-1+g(32)*1+g(35)*-1+g(36)*1)  /  T  );
revk(208)=kf/Kc*Y(32)*Y(36);

kf=kfarray(209);
fwdk(209)=kf*Y(2)*Y(35);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(35)*-1+g(48)*1)  /  T  );
revk(209)=kf/Kc*Y(1)*Y(48);

kf=kfarray(210);
fwdk(210)=kf*Y(5)*Y(35);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(35)*-1+g(48)*1)  /  T  );
revk(210)=kf/Kc*Y(6)*Y(48);

kf=kfarray(211);
fwdk(211)=kf*Y(13)*Y(35);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(35)*-1+g(48)*1)  /  T  );
revk(211)=kf/Kc*Y(14)*Y(48);

kf=kfarray(212)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(212)=kf*Y(2)*Y(36);
Kc=exp(   -(+g(2)*-1+g(36)*-1+g(39)*1)  /  T  )*(T/PATM);
revk(212)=kf/Kc*Y(39);

kf=kfarray(213);
fwdk(213)=kf*Y(3)*Y(39);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(36)*1+g(39)*-1)  /  T  );
revk(213)=kf/Kc*Y(5)*Y(36);

kf=kfarray(214);
fwdk(214)=kf*Y(2)*Y(39);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(36)*1+g(39)*-1)  /  T  );
revk(214)=kf/Kc*Y(1)*Y(36);

kf=kfarray(215);
fwdk(215)=kf*Y(5)*Y(39);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(36)*1+g(39)*-1)  /  T  );
revk(215)=kf/Kc*Y(6)*Y(36);

kf=kfarray(216);
fwdk(216)=kf*Y(4)*Y(39);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(36)*1+g(39)*-1)  /  T  );
revk(216)=kf/Kc*Y(7)*Y(36);

kf=kfarray(217);
fwdk(217)=kf*Y(3)*Y(40);
Kc=exp(   -(+g(3)*-1+g(15)*1+g(31)*1+g(40)*-1)  /  T  );
revk(217)=kf/Kc*Y(15)*Y(31);

kf=kfarray(218);
fwdk(218)=kf*Y(5)*Y(40);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(40)*-1+g(47)*1)  /  T  );
revk(218)=kf/Kc*Y(2)*Y(47);

kf=kfarray(219);
fwdk(219)=kf*Y(6)*Y(40);
Kc=exp(   -(+g(5)*1+g(6)*-1+g(40)*-1+g(41)*1)  /  T  );
revk(219)=kf/Kc*Y(5)*Y(41);

kf=kfarray(220);
fwdk(220)=kf*Y(4)*Y(40);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(40)*-1+g(47)*1)  /  T  );
revk(220)=kf/Kc*Y(3)*Y(47);

kf=kfarray(221);
fwdk(221)=kf*Y(1)*Y(40);
Kc=exp(   -(+g(1)*-1+g(2)*1+g(40)*-1+g(41)*1)  /  T  );
revk(221)=kf/Kc*Y(2)*Y(41);

kf=kfarray(222);
fwdk(222)=kf*Y(3)*Y(47);
Kc=exp(   -(+g(3)*-1+g(15)*1+g(36)*1+g(47)*-1)  /  T  );
revk(222)=kf/Kc*Y(15)*Y(36);

kf=kfarray(223);
fwdk(223)=kf*Y(2)*Y(47);
Kc=exp(   -(+g(2)*-1+g(15)*1+g(32)*1+g(47)*-1)  /  T  );
revk(223)=kf/Kc*Y(15)*Y(32);

kf=kfarray(224);
fwdk(224)=kf*Y(5)*Y(47);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(15)*1+g(36)*1+g(47)*-1)  /  T  )/(T/PATM);
revk(224)=kf/Kc*Y(2)*Y(15)*Y(36);

kf=kfarray(225);
fwdk(225)=kf*Y(31)*Y(47);
Kc=exp(   -(+g(15)*1+g(31)*-1+g(47)*-1+g(48)*1)  /  T  );
revk(225)=kf/Kc*Y(15)*Y(48);

kf=kfarray(226);
fwdk(226)=kf*Y(4)*Y(47);
Kc=exp(   -(+g(4)*-1+g(16)*1+g(36)*1+g(47)*-1)  /  T  );
revk(226)=kf/Kc*Y(16)*Y(36);

kf=kfarray(227)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(227)=kf*Y(47);
Kc=exp(   -(+g(15)*1+g(31)*1+g(47)*-1)  /  T  )/(T/PATM);
revk(227)=kf/Kc*Y(15)*Y(31);

kf=kfarray(228);
fwdk(228)=kf*Y(36)*Y(47);
Kc=exp(   -(+g(15)*1+g(36)*-1+g(38)*1+g(47)*-1)  /  T  );
revk(228)=kf/Kc*Y(15)*Y(38);

kf=kfarray(229);
fwdk(229)=kf*Y(36)*Y(47);
Kc=exp(   -(+g(16)*1+g(36)*-1+g(47)*-1+g(48)*1)  /  T  );
revk(229)=kf/Kc*Y(16)*Y(48);

kf=kfarray(230)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(230)=kf*Y(41);
Kc=exp(   -(+g(2)*1+g(40)*1+g(41)*-1)  /  T  )/(T/PATM);
revk(230)=kf/Kc*Y(2)*Y(40);

kf=kfarray(231);
fwdk(231)=kf*Y(3)*Y(41);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(41)*-1+g(47)*1)  /  T  );
revk(231)=kf/Kc*Y(2)*Y(47);

kf=kfarray(232);
fwdk(232)=kf*Y(3)*Y(41);
Kc=exp(   -(+g(3)*-1+g(15)*1+g(32)*1+g(41)*-1)  /  T  );
revk(232)=kf/Kc*Y(15)*Y(32);

kf=kfarray(233);
fwdk(233)=kf*Y(3)*Y(41);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(40)*1+g(41)*-1)  /  T  );
revk(233)=kf/Kc*Y(5)*Y(40);

kf=kfarray(234);
fwdk(234)=kf*Y(5)*Y(41);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(41)*-1+g(45)*1)  /  T  );
revk(234)=kf/Kc*Y(2)*Y(45);

kf=kfarray(235);
fwdk(235)=kf*Y(5)*Y(41);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(41)*-1+g(46)*1)  /  T  );
revk(235)=kf/Kc*Y(2)*Y(46);

kf=kfarray(236);
fwdk(236)=kf*Y(5)*Y(41);
Kc=exp(   -(+g(5)*-1+g(15)*1+g(33)*1+g(41)*-1)  /  T  );
revk(236)=kf/Kc*Y(15)*Y(33);

%lindemann approach
k0=1.400E+26*T^-3.400*exp(-9.561117e+02/T);
kinf=kfarray(237);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
F=1;
kf=kinf*(Pr/(1+Pr))*F;
fwdk(237)=kf*Y(2)*Y(41);
Kc=exp(   -(+g(2)*-1+g(41)*-1+g(42)*1)  /  T  )*(T/PATM);
revk(237)=kf/Kc*Y(42);

kf=kfarray(238);
fwdk(238)=kf*Y(31)*Y(42);
Kc=exp(   -(+g(11)*1+g(31)*-1+g(42)*-1+g(48)*1)  /  T  );
revk(238)=kf/Kc*Y(11)*Y(48);

kf=kfarray(239);
fwdk(239)=kf*Y(9)*Y(48);
Kc=exp(   -(+g(9)*-1+g(31)*1+g(40)*1+g(48)*-1)  /  T  );
revk(239)=kf/Kc*Y(31)*Y(40);

kf=kfarray(240);
fwdk(240)=kf*Y(10)*Y(48);
Kc=exp(   -(+g(10)*-1+g(31)*1+g(41)*1+g(48)*-1)  /  T  );
revk(240)=kf/Kc*Y(31)*Y(41);

%lindemann approach
k0=1.300E+25*T^-3.160*exp(-3.723803e+02/T);
kinf=kfarray(241);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*0))/kinf;
%Troe form
a=.6670;%alpha
T3=235.00;%T***
T1=2117.00;%T*
T2=4536.00;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(241)=kf*Y(10)*Y(48);
Kc=exp(   -(+g(10)*-1+g(43)*1+g(48)*-1)  /  T  )*(T/PATM);
revk(241)=kf/Kc*Y(43);

kf=kfarray(242);
fwdk(242)=kf*Y(11)*Y(48);
Kc=exp(   -(+g(11)*-1+g(32)*1+g(41)*1+g(48)*-1)  /  T  );
revk(242)=kf/Kc*Y(32)*Y(41);

kf=kfarray(243);
fwdk(243)=kf*Y(12)*Y(48);
Kc=exp(   -(+g(12)*-1+g(32)*1+g(41)*1+g(48)*-1)  /  T  );
revk(243)=kf/Kc*Y(32)*Y(41);

kf=kfarray(244);
fwdk(244)=kf*Y(9)*Y(36);
Kc=exp(   -(+g(3)*1+g(9)*-1+g(36)*-1+g(40)*1)  /  T  );
revk(244)=kf/Kc*Y(3)*Y(40);

kf=kfarray(245);
fwdk(245)=kf*Y(9)*Y(36);
Kc=exp(   -(+g(9)*-1+g(15)*1+g(31)*1+g(36)*-1)  /  T  );
revk(245)=kf/Kc*Y(15)*Y(31);

kf=kfarray(246);
fwdk(246)=kf*Y(10)*Y(36);
Kc=exp(   -(+g(3)*1+g(10)*-1+g(36)*-1+g(41)*1)  /  T  );
revk(246)=kf/Kc*Y(3)*Y(41);

kf=kfarray(247);
fwdk(247)=kf*Y(10)*Y(36);
Kc=exp(   -(+g(2)*1+g(10)*-1+g(36)*-1+g(47)*1)  /  T  );
revk(247)=kf/Kc*Y(2)*Y(47);

kf=kfarray(248);
fwdk(248)=kf*Y(10)*Y(36);
Kc=exp(   -(+g(10)*-1+g(17)*1+g(31)*1+g(36)*-1)  /  T  );
revk(248)=kf/Kc*Y(17)*Y(31);

kf=kfarray(249);
fwdk(249)=kf*Y(11)*Y(36);
Kc=exp(   -(+g(2)*1+g(11)*-1+g(36)*-1+g(46)*1)  /  T  );
revk(249)=kf/Kc*Y(2)*Y(46);

kf=kfarray(250);
fwdk(250)=kf*Y(11)*Y(36);
Kc=exp(   -(+g(5)*1+g(11)*-1+g(36)*-1+g(41)*1)  /  T  );
revk(250)=kf/Kc*Y(5)*Y(41);

kf=kfarray(251);
fwdk(251)=kf*Y(11)*Y(36);
Kc=exp(   -(+g(2)*1+g(11)*-1+g(36)*-1+g(44)*1)  /  T  );
revk(251)=kf/Kc*Y(2)*Y(44);

kf=kfarray(252);
fwdk(252)=kf*Y(12)*Y(36);
Kc=exp(   -(+g(2)*1+g(12)*-1+g(36)*-1+g(46)*1)  /  T  );
revk(252)=kf/Kc*Y(2)*Y(46);

kf=kfarray(253);
fwdk(253)=kf*Y(12)*Y(36);
Kc=exp(   -(+g(5)*1+g(12)*-1+g(36)*-1+g(41)*1)  /  T  );
revk(253)=kf/Kc*Y(5)*Y(41);

kf=kfarray(254);
fwdk(254)=kf*Y(12)*Y(36);
Kc=exp(   -(+g(2)*1+g(12)*-1+g(36)*-1+g(44)*1)  /  T  );
revk(254)=kf/Kc*Y(2)*Y(44);

kf=kfarray(255);
fwdk(255)=kf*Y(13)*Y(36);
Kc=exp(   -(+g(6)*1+g(13)*-1+g(36)*-1+g(41)*1)  /  T  );
revk(255)=kf/Kc*Y(6)*Y(41);

kf=kfarray(256);
fwdk(256)=kf*Y(13)*Y(36);
Kc=exp(   -(+g(5)*1+g(13)*-1+g(36)*-1+g(42)*1)  /  T  );
revk(256)=kf/Kc*Y(5)*Y(42);

kf=kfarray(257);
fwdk(257)=kf*Y(3)*Y(43);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(15)*1+g(43)*-1+g(48)*1)  /  T  )/(T/PATM);
revk(257)=kf/Kc*Y(2)*Y(15)*Y(48);

kf=kfarray(258);
fwdk(258)=kf*Y(3)*Y(43);
Kc=exp(   -(+g(3)*-1+g(36)*1+g(41)*1+g(43)*-1)  /  T  );
revk(258)=kf/Kc*Y(36)*Y(41);

kf=kfarray(259);
fwdk(259)=kf*Y(4)*Y(43);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(17)*1+g(43)*-1+g(48)*1)  /  T  )/(T/PATM);
revk(259)=kf/Kc*Y(3)*Y(17)*Y(48);

kf=kfarray(260);
fwdk(260)=kf*Y(5)*Y(43);
Kc=exp(   -(+g(2)*1+g(5)*-1+g(17)*1+g(43)*-1+g(48)*1)  /  T  )/(T/PATM);
revk(260)=kf/Kc*Y(2)*Y(17)*Y(48);

kf=kfarray(261);
fwdk(261)=kf*Y(2)*Y(43);
Kc=exp(   -(+g(2)*-1+g(11)*1+g(43)*-1+g(48)*1)  /  T  );
revk(261)=kf/Kc*Y(11)*Y(48);

kf=kfarray(262);
fwdk(262)=kf*Y(3)*Y(46);
Kc=exp(   -(+g(3)*-1+g(16)*1+g(32)*1+g(46)*-1)  /  T  );
revk(262)=kf/Kc*Y(16)*Y(32);

kf=kfarray(263);
fwdk(263)=kf*Y(3)*Y(46);
Kc=exp(   -(+g(3)*-1+g(15)*1+g(39)*1+g(46)*-1)  /  T  );
revk(263)=kf/Kc*Y(15)*Y(39);

kf=kfarray(264);
fwdk(264)=kf*Y(3)*Y(46);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(46)*-1+g(47)*1)  /  T  );
revk(264)=kf/Kc*Y(5)*Y(47);

kf=kfarray(265);
fwdk(265)=kf*Y(2)*Y(46);
Kc=exp(   -(+g(2)*-1+g(15)*1+g(33)*1+g(46)*-1)  /  T  );
revk(265)=kf/Kc*Y(15)*Y(33);

kf=kfarray(266);
fwdk(266)=kf*Y(2)*Y(46);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(46)*-1+g(47)*1)  /  T  );
revk(266)=kf/Kc*Y(1)*Y(47);

kf=kfarray(267);
fwdk(267)=kf*Y(5)*Y(46);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(46)*-1+g(47)*1)  /  T  );
revk(267)=kf/Kc*Y(6)*Y(47);

kf=kfarray(268);
fwdk(268)=kf*Y(5)*Y(46);
Kc=exp(   -(+g(5)*-1+g(16)*1+g(33)*1+g(46)*-1)  /  T  );
revk(268)=kf/Kc*Y(16)*Y(33);

kf=kfarray(269)*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3);
fwdk(269)=kf*Y(46);
Kc=exp(   -(+g(15)*1+g(32)*1+g(46)*-1)  /  T  )/(T/PATM);
revk(269)=kf/Kc*Y(15)*Y(32);

kf=kfarray(270);
fwdk(270)=kf*Y(2)*Y(44);
Kc=exp(   -(+g(44)*-1+g(46)*1)  /  T  );
revk(270)=kf/Kc*Y(2)*Y(46);

kf=kfarray(271);
fwdk(271)=kf*Y(2)*Y(44);
Kc=exp(   -(+g(2)*-1+g(5)*1+g(41)*1+g(44)*-1)  /  T  );
revk(271)=kf/Kc*Y(5)*Y(41);

kf=kfarray(272);
fwdk(272)=kf*Y(2)*Y(44);
Kc=exp(   -(+g(2)*-1+g(15)*1+g(33)*1+g(44)*-1)  /  T  );
revk(272)=kf/Kc*Y(15)*Y(33);

kf=kfarray(273);
fwdk(273)=kf*Y(2)*Y(45);
Kc=exp(   -(+g(45)*-1+g(46)*1)  /  T  );
revk(273)=kf/Kc*Y(2)*Y(46);

kf=kfarray(274);
fwdk(274)=kf*Y(28)*Y(36);
Kc=exp(   -(+g(15)*1+g(28)*-1+g(36)*-1+g(44)*1)  /  T  );
revk(274)=kf/Kc*Y(15)*Y(44);

kf=kfarray(275);
fwdk(275)=kf*Y(13)*Y(31);
Kc=exp(   -(+g(2)*1+g(13)*-1+g(31)*-1+g(42)*1)  /  T  );
revk(275)=kf/Kc*Y(2)*Y(42);

kf=kfarray(276);
fwdk(276)=kf*Y(13)*Y(31);
Kc=exp(   -(+g(1)*1+g(13)*-1+g(31)*-1+g(41)*1)  /  T  );
revk(276)=kf/Kc*Y(1)*Y(41);

kf=kfarray(277);
fwdk(277)=kf*Y(2)*Y(34);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(33)*1+g(34)*-1)  /  T  );
revk(277)=kf/Kc*Y(1)*Y(33);

kf=kfarray(278);
fwdk(278)=kf*Y(5)*Y(34);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(33)*1+g(34)*-1)  /  T  );
revk(278)=kf/Kc*Y(6)*Y(33);

kf=kfarray(279);
fwdk(279)=kf*Y(3)*Y(34);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(33)*1+g(34)*-1)  /  T  );
revk(279)=kf/Kc*Y(5)*Y(33);

kf=kfarray(280);
fwdk(280)=kf*Y(16)*Y(32);
Kc=exp(   -(+g(15)*1+g(16)*-1+g(32)*-1+g(39)*1)  /  T  );
revk(280)=kf/Kc*Y(15)*Y(39);

kf=kfarray(281);
fwdk(281)=kf*Y(37)*Y(40);
Kc=exp(   -(+g(36)*1+g(37)*-1+g(40)*-1+g(47)*1)  /  T  );
revk(281)=kf/Kc*Y(36)*Y(47);

kf=kfarray(282);
fwdk(282)=kf*Y(37)*Y(47);
Kc=exp(   -(+g(16)*1+g(37)*-1+g(38)*1+g(47)*-1)  /  T  );
revk(282)=kf/Kc*Y(16)*Y(38);

kf=kfarray(283);
fwdk(283)=kf*Y(16)*Y(31);
Kc=exp(   -(+g(15)*1+g(16)*-1+g(31)*-1+g(36)*1)  /  T  );
revk(283)=kf/Kc*Y(15)*Y(36);

kf=kfarray(284);
fwdk(284)=kf*Y(3)*Y(13);

kf=kfarray(285);
fwdk(285)=kf*Y(3)*Y(25);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(25)*-1+g(52)*1)  /  T  );
revk(285)=kf/Kc*Y(2)*Y(52);

kf=kfarray(286);
fwdk(286)=kf*Y(3)*Y(26);
Kc=exp(   -(+g(2)*1+g(3)*-1+g(26)*-1+g(53)*1)  /  T  );
revk(286)=kf/Kc*Y(2)*Y(53);

kf=kfarray(287);
fwdk(287)=kf*Y(5)*Y(7);
Kc=exp(   -(+g(4)*1+g(5)*-1+g(6)*1+g(7)*-1)  /  T  );
revk(287)=kf/Kc*Y(4)*Y(6);

kf=kfarray(288);
fwdk(288)=kf*Y(5)*Y(13);

%lindemann approach
k0=4.820E+25*T^-2.80*exp(-2.968978e+02/T);
kinf=kfarray(289);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.578;%alpha
T3=122.0;%T***
T1=2535.0;%T*
T2=9365.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(289)=kf*Y(1)*Y(10);
Kc=exp(   -(+g(1)*-1+g(10)*-1+g(13)*1)  /  T  )*(T/PATM);
revk(289)=kf/Kc*Y(13);

kf=kfarray(290);
fwdk(290)=kf*Y(4)*Y(11);

kf=kfarray(291);
fwdk(291)=kf*Y(4)*Y(11);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(11)*-1+g(18)*1)  /  T  );
revk(291)=kf/Kc*Y(3)*Y(18);

kf=kfarray(292);
fwdk(292)=kf*Y(11)*Y(11);

kf=kfarray(293);
fwdk(293)=kf*Y(6)*Y(12);

kf=kfarray(294);
fwdk(294)=kf*Y(4)*Y(24);
Kc=exp(   -(+g(3)*1+g(4)*-1+g(24)*-1+g(52)*1)  /  T  );
revk(294)=kf/Kc*Y(3)*Y(52);

kf=kfarray(295);
fwdk(295)=kf*Y(4)*Y(24);
Kc=exp(   -(+g(4)*-1+g(7)*1+g(23)*1+g(24)*-1)  /  T  );
revk(295)=kf/Kc*Y(7)*Y(23);

kf=kfarray(296);
fwdk(296)=kf*Y(3)*Y(53);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(52)*1+g(53)*-1)  /  T  );
revk(296)=kf/Kc*Y(5)*Y(52);

kf=kfarray(297);
fwdk(297)=kf*Y(3)*Y(53);

kf=kfarray(298);
fwdk(298)=kf*Y(4)*Y(53);

kf=kfarray(299);
fwdk(299)=kf*Y(2)*Y(53);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(52)*1+g(53)*-1)  /  T  );
revk(299)=kf/Kc*Y(1)*Y(52);

kf=kfarray(300);
fwdk(300)=kf*Y(2)*Y(53);

kf=kfarray(301);
fwdk(301)=kf*Y(5)*Y(53);

kf=kfarray(302);
fwdk(302)=kf*Y(7)*Y(53);

kf=kfarray(303);
fwdk(303)=kf*Y(13)*Y(53);

%lindemann approach
k0=1.012E+42*T^-7.63*exp(-1.939397e+03/T);
kinf=kfarray(304);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=0.465;%alpha
T3=201.0;%T***
T1=1773.0;%T*
T2=5333.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(304)=kf*Y(2)*Y(29);
Kc=exp(   -(+g(2)*-1+g(29)*-1+g(52)*1)  /  T  )*(T/PATM);
revk(304)=kf/Kc*Y(52);

kf=kfarray(305);
fwdk(305)=kf*Y(3)*Y(52);

kf=kfarray(306);
fwdk(306)=kf*Y(4)*Y(52);

kf=kfarray(307);
fwdk(307)=kf*Y(4)*Y(52);

kf=kfarray(308);
fwdk(308)=kf*Y(2)*Y(52);
Kc=exp(   -(+g(2)*-1+g(13)*1+g(17)*1+g(52)*-1)  /  T  );
revk(308)=kf/Kc*Y(13)*Y(17);

kf=kfarray(309);
fwdk(309)=kf*Y(2)*Y(52);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(29)*1+g(52)*-1)  /  T  );
revk(309)=kf/Kc*Y(1)*Y(29);

kf=kfarray(310);
fwdk(310)=kf*Y(5)*Y(52);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(29)*1+g(52)*-1)  /  T  );
revk(310)=kf/Kc*Y(6)*Y(29);

kf=kfarray(311);
fwdk(311)=kf*Y(5)*Y(52);
Kc=exp(   -(+g(5)*-1+g(17)*1+g(19)*1+g(52)*-1)  /  T  );
revk(311)=kf/Kc*Y(17)*Y(19);

%lindemann approach
k0=2.710E+74*T^-16.82*exp(-6.574526e+03/T);
kinf=kfarray(312);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.1527;%alpha
T3=291.0;%T***
T1=2742.0;%T*
T2=7748.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(312)=kf*Y(13)*Y(26);
Kc=exp(   -(+g(13)*-1+g(26)*-1+g(51)*1)  /  T  )*(T/PATM);
revk(312)=kf/Kc*Y(51);

kf=kfarray(313);
fwdk(313)=kf*Y(3)*Y(51);
Kc=exp(   -(+g(3)*-1+g(5)*1+g(50)*1+g(51)*-1)  /  T  );
revk(313)=kf/Kc*Y(5)*Y(50);

kf=kfarray(314);
fwdk(314)=kf*Y(2)*Y(51);
Kc=exp(   -(+g(1)*1+g(2)*-1+g(50)*1+g(51)*-1)  /  T  );
revk(314)=kf/Kc*Y(1)*Y(50);

kf=kfarray(315);
fwdk(315)=kf*Y(5)*Y(51);
Kc=exp(   -(+g(5)*-1+g(6)*1+g(50)*1+g(51)*-1)  /  T  );
revk(315)=kf/Kc*Y(6)*Y(50);

kf=kfarray(316);
fwdk(316)=kf*Y(8)*Y(50);
Kc=exp(   -(+g(7)*1+g(8)*-1+g(50)*-1+g(51)*1)  /  T  );
revk(316)=kf/Kc*Y(7)*Y(51);

kf=kfarray(317);
fwdk(317)=kf*Y(13)*Y(51);
Kc=exp(   -(+g(13)*-1+g(14)*1+g(50)*1+g(51)*-1)  /  T  );
revk(317)=kf/Kc*Y(14)*Y(50);

%lindemann approach
k0=3.00E+63*T^-14.6*exp(-9.143447e+03/T);
kinf=kfarray(318);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.1894;%alpha
T3=277.0;%T***
T1=8748.0;%T*
T2=7891.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(318)=kf*Y(13)*Y(25);
Kc=exp(   -(+g(13)*-1+g(25)*-1+g(50)*1)  /  T  )*(T/PATM);
revk(318)=kf/Kc*Y(50);

kf=kfarray(319);
fwdk(319)=kf*Y(3)*Y(50);
Kc=exp(   -(+g(3)*-1+g(18)*1+g(26)*1+g(50)*-1)  /  T  );
revk(319)=kf/Kc*Y(18)*Y(26);

%lindemann approach
k0=4.420E+61*T^-13.545*exp(-5.715032e+03/T);
kinf=kfarray(320);
Pr=(k0*(sumY+Y(1)*1+Y(6)*5+Y(14)*1+Y(15)*0.5+Y(16)*1+Y(27)*2+Y(49)*-0.3))/kinf;
%Troe form
a=.315;%alpha
T3=369.0;%T***
T1=3285.0;%T*
T2=6667.0;%T**
Fcent=(1-a)*exp(-T/T3)+a*exp(-T/T1)+exp(-T2/T);
c = -0.4 - 0.67*log10(Fcent);
n = 0.75 - 1.27*log10(Fcent);
F=10^(log10(Fcent)*(1+(  (log10(Pr)+c)/(n-d*(log10(Pr)+c))  )^2)^-1);
kf=kinf*(Pr/(1+Pr))*F;
fwdk(320)=kf*Y(2)*Y(50);
Kc=exp(   -(+g(2)*-1+g(50)*-1+g(51)*1)  /  T  )*(T/PATM);
revk(320)=kf/Kc*Y(51);

kf=kfarray(321);
fwdk(321)=kf*Y(2)*Y(50);
Kc=exp(   -(+g(2)*-1+g(13)*1+g(26)*1+g(50)*-1)  /  T  );
revk(321)=kf/Kc*Y(13)*Y(26);

kf=kfarray(322);
fwdk(322)=kf*Y(5)*Y(50);
Kc=exp(   -(+g(5)*-1+g(19)*1+g(26)*1+g(50)*-1)  /  T  );
revk(322)=kf/Kc*Y(19)*Y(26);

kf=kfarray(323);
fwdk(323)=kf*Y(7)*Y(50);
Kc=exp(   -(+g(4)*1+g(7)*-1+g(50)*-1+g(51)*1)  /  T  );
revk(323)=kf/Kc*Y(4)*Y(51);

kf=kfarray(324);
fwdk(324)=kf*Y(7)*Y(50);

kf=kfarray(325);
fwdk(325)=kf*Y(13)*Y(50);
Kc=exp(   -(+g(13)*-1+g(26)*2+g(50)*-1)  /  T  );
revk(325)=kf/Kc*Y(26)*Y(26);

end