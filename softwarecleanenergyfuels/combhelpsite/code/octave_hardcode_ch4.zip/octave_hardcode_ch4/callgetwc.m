% Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms
% Copyright (C) 2014  Max Plomer
 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact info for Max Plomer
% email: maxplomer@gmail.com
% cell: 203-945-8606

function callgetwc
fprintf('Software for Clean Energy Fuels  Copyright (C) 2014  Max Plomer\n');
fprintf('This program comes with ABSOLUTELY NO WARRANTY.\n');
fprintf('This is free software, and you are welcome to redistribute it\n');
fprintf('under certain conditions.\n\n');
 
fprintf('Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms\n');
fprintf('Copyright (C) 2014  Max Plomer\n\n');
 
fprintf('This program is free software: you can redistribute it and/or modify\n');
fprintf('it under the terms of the GNU General Public License as published by\n');
fprintf('the Free Software Foundation, either version 3 of the License, or\n');
fprintf('(at your option) any later version.\n\n');
 
fprintf('This program is distributed in the hope that it will be useful,\n');
fprintf('but WITHOUT ANY WARRANTY; without even the implied warranty of\n');
fprintf('MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n');
fprintf('GNU General Public License for more details.\n\n');
 
fprintf('You should have received a copy of the GNU General Public License\n');
fprintf('along with this program.  If not, see <http://www.gnu.org/licenses/>.\n\n');

fprintf('Contact info for Max Plomer\n');
fprintf('email: maxplomer@gmail.com\n');
fprintf('cell: 203-945-8606\n\n');

T=1000;

C=ones(1,53);
C=C';

wdot=getwc(T, C); %molelar production rate

end