% Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms
% Copyright (C) 2014  Max Plomer
 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact info for Max Plomer
% email: maxplomer@gmail.com
% cell: 203-945-8606

function [A,B,E]=getabe
A=[3.547e+15
0.508E+05
0.216E+09
2.97e+06
4.577E+19
6.165E+15
4.714E+18
3.800E+22
1.475E+12
1.66E+13
7.079E+13
0.325E+14
2.890E+13
4.200e+14
1.300e+11
2.951e+14
0.241E+14
0.482E+14
9.550E+06
1.000E+12
5.800E+14];
B=[-0.406
2.67
1.51
2.02
-1.40
-0.50
-1.00
-2.00
0.60
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
2.00
0.00
0.00];
E=[1.6599E+4
0.629E+04
0.343E+04
1.34e+4
1.0438E+05
0.000E+00
0.000E+00
0.000E+00
0.00E+00
0.823E+03
2.95E+02
0.00E+00
-4.970E+02
1.1982e+04
-1.6293e+3
4.843E+04
0.397E+04
0.795E+04
3.970E+03
0.000	
9.557E+03];
end