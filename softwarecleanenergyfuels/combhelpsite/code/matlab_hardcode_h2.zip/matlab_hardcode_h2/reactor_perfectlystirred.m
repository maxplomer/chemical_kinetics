% Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms
% Copyright (C) 2014  Max Plomer
 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Contact info for Max Plomer
% email: maxplomer@gmail.com
% cell: 203-945-8606

function reactor_perfectlystirred
fprintf('Software for Clean Energy Fuels  Copyright (C) 2014  Max Plomer\n');
fprintf('This program comes with ABSOLUTELY NO WARRANTY.\n');
fprintf('This is free software, and you are welcome to redistribute it\n');
fprintf('under certain conditions.\n\n');
 
fprintf('Software for Clean Energy Fuels - Calculates reaction rates from fuel mechanisms\n');
fprintf('Copyright (C) 2014  Max Plomer\n\n');
 
fprintf('This program is free software: you can redistribute it and/or modify\n');
fprintf('it under the terms of the GNU General Public License as published by\n');
fprintf('the Free Software Foundation, either version 3 of the License, or\n');
fprintf('(at your option) any later version.\n\n');
 
fprintf('This program is distributed in the hope that it will be useful,\n');
fprintf('but WITHOUT ANY WARRANTY; without even the implied warranty of\n');
fprintf('MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n');
fprintf('GNU General Public License for more details.\n\n');
 
fprintf('You should have received a copy of the GNU General Public License\n');
fprintf('along with this program.  If not, see <http://www.gnu.org/licenses/>.\n\n');

fprintf('Contact info for Max Plomer\n');
fprintf('email: maxplomer@gmail.com\n');
fprintf('cell: 203-945-8606\n\n');

global N commonT;
[N,commonT]=getthermodata;

RU=83145100;%erg/(mol*K)
PA=1013250; %1 atm = 1 013 250 erg / (centimeter^3)
W=getwt;

% number of variables
KK=getKK;     %# of species
NV = KK+1;    %# of variables

%system conditions
p = 1; % atm
P = p*PA;
T = 1200;
Phi = 0.5;
tau=1; %1 second

%variables
nY = 1:KK;
nT = KK+1;


% setup the initial conditions - auto calculation of stoich ratio of
% oxdiant to fuel
Y0 = zeros(KK,1);
fuel_species={'H2'};
fuel_ratio=[1];
oxidant_species='O2';
dilutant_species='N2';
dilutant_ratio=3.76; %ratio of dilutant to oxidant

%C H O element composition order
c_order=findelement('c'); h_order = findelement('h'); o_order = findelement('o');
c_tot=0;h_tot=0;o_tot=0;
comp=getcomposition;
for j=1:length(fuel_species)
    A=findsp(fuel_species{j});
    c_tot = c_tot + fuel_ratio(j) * comp(A,c_order);
    h_tot = h_tot + fuel_ratio(j) * comp(A,h_order);
	o_tot = o_tot + fuel_ratio(j) * comp(A,o_order);
end
amount_oxidant=h_tot/4 + c_tot - o_tot/2;%calculate stoich amount of oxidant
%initial mass fractions
for j=1:length(fuel_species)
   Y0(findsp(fuel_species{j}))=W(findsp(fuel_species{j}))*fuel_ratio(j); 
end
Y0(findsp(oxidant_species))=W(findsp(oxidant_species))*amount_oxidant/Phi;
Y0(findsp(dilutant_species))=W(findsp(dilutant_species))*dilutant_ratio*amount_oxidant/Phi;
Y0 = Y0/sum(Y0);




% % setup the initial conditions -simple
% Y0 = zeros(KK,1);
% I_CH4 = findsp('CH4');
% I_O2 = findsp('O2');
% I_N2 = findsp('N2');
% 
% %initial mass fractions
% Y0(I_CH4) = W(I_CH4)*Phi*0.5;
% Y0(I_O2) = W(I_O2)*1;
% Y0(I_N2) = W(I_N2)*3.76;
% Y0 = Y0/sum(Y0);

% here is where i put the different IC vectors 
% into the main IC vector
y0 = zeros(NV,1);
y0(nY) = Y0;
y0(nT) = T; %temperature

h0=geth(T)./W;

%time span 0 to .1 seconds
tspan = [0 .001]; % .1 seconds

% setup and run the matlab integration solver
options = odeset('RelTol', 1.0E-6, 'AbsTol', 1.0E-9);
[t ,y] = ode15s(@ignfun, tspan, y0, options);

% plot the results
plot(t, y(:, nT));
xlabel('Time (sec)');
ylabel('Temperature (K)');
xlim([0 .001]);






    % RHS functions of the ODEs
    %   input:  t is the time 
    %           y: the vector of indepdent variables 
    %   output: dydt: the vector of LHS of the ODE
    %
    function dydt = ignfun(t, y)  %time, mass faction
        dydt = zeros(NV,1);

        Y = y(nY);
        T = y(nT);
        
        %calculate average molecular weight
        WM = 1/sum(Y./W);

        rho = P*WM/(RU*T);  %density from p=roe*R_g*T

        cp=getcp(T)./W;%vector of cv mass based

        h=geth(T)./W;
        
        cpm = dot(cp, Y);%dot product of cp vector and mass fraction vector is mean cp
        
        c=(Y./W)*rho;
        
        wdot=getwc(T, c);
        
        % change in mass fractions per time, dY/dt
        dYdt = (Y0-Y)/tau + wdot.*W/rho;
        
        % change in temperature per time, dT/dt
        dTdt = sum(Y.*(h0-h))/(tau*cpm)-sum(h.*wdot.*W)/(rho*cpm);
        
        dydt(nY) = dYdt;
        dydt(nT) = dTdt;
        
    end
end
