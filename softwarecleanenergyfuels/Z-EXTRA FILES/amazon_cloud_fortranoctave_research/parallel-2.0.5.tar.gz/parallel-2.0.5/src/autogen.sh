#! /bin/sh

autoconf
