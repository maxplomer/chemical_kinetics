=============================================================
// FREE PREMIUM BUSINESS CARD TEMPLATE //////////////////////
=============================================================

Designed by www.free-business-card-templates.com and released
exclusively at hongkiat.com


=============================================================
// LICENSE //////////////////////////////////////////////////
=============================================================

This business card template are free for both commercial and
personal use unless stated. You cannot distribute, lease,
license, sell and upload to any file sharing network or
website without a prior written permission from
free-business-card-templates.com


=============================================================
// FONTS ////////////////////////////////////////////////////
=============================================================

Download free fonts used in this template

1) Bebas Neue - http://www.fontsquirrel.com/fonts/bebas-neue
2) Colaborate - http://www.fontsquirrel.com/fonts/Colaborate


=============================================================
// QR Code //////////////////////////////////////////////////
=============================================================

QR Code generator

http://www.i-nigma.com/CreateBarcodes.html